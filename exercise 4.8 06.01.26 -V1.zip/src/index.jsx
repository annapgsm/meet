atatus.config('f63b49ebc0b9430692c66eaa1b807652').install();
atatus.notify(new Error('Test Atatus Setup'));